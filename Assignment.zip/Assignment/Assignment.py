import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Set up the webdriver
options = webdriver.ChromeOptions()
options.add_argument('headless')
driver = webdriver.Chrome(options=options)

# Navigate to the website
driver.get('https://hprera.nic.in/PublicDashboard')

# Wait for the "Registered Projects" section to load
registered_projects = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, '//h2[text()="Registered Projects"]/following-sibling::table'))
)

# Extract the first 6 project links
project_links = [a.get_attribute('href') for a in registered_projects.find_elements_by_tag_name('a')[:6]]

# Create lists to store the project details
gstins = []
pans = []
names = []
addresses = []

# Loop through each project link
for link in project_links:
    driver.get(link)
    content = driver.page_source
    soup = BeautifulSoup(content, 'html.parser')
    
    # Extract the project details
    gstin = soup.find('th', text='GSTIN No.').find_next('td').text
    pan = soup.find('th', text='PAN No.').find_next('td').text
    name = soup.find('th', text='Project Name').find_next('td').text
    address = soup.find('th', text='Project Address').find_next('td').text
    
    # Append the details to the lists
    gstins.append(gstin)
    pans.append(pan)
    names.append(name)
    addresses.append(address)

# Create a pandas dataframe
df = pd.DataFrame({'GSTIN No': gstins, 'PAN No': pans, 'Name': names, 'Permanent Address': addresses})

# Save the dataframe to a CSV file
df.to_csv('projects.csv', index=False, encoding='utf-8')

# Close the webdriver
driver.quit()